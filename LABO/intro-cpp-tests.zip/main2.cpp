// g++ mis_funciones.cpp main2.cpp -o main && ./main2

#include <iostream>
#include "mis_funciones.h"

using namespace std;

void t(string c, bool b) {
  cout << c << "...";
  if (b) {
    cout << "ok";
  } else {
    cout << "mal";
  }
  cout << endl;
}

int main() {

  t("3!", factorial(3) == 6);

  t("4!", factorial(4) == 24);

  return 0;
}
