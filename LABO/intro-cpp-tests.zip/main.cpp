// g++ mis_funciones.cpp main.cpp -o main && ./main

#include <iostream>
#include "mis_funciones.h"

using namespace std;

int main() {

  cout << "3! = " << factorial(3) << endl;

  int num;
  cout << "ingrese num: ";
  cin >> num;
  cout << "su factorial: " << factorial(num) << endl;

  return 0;
}
