// g++ mis_funciones.cpp tests.cpp -o tests && ./tests

#include "mini_test.h"
#include "mis_funciones.h"

void fact_1() {
  int n = factorial(1);
  ASSERT_EQ(n, 1);
}

void fact_3() {
  ASSERT_EQ(factorial(3), 6);
}

void fact_6() {
  ASSERT_EQ(factorial(6), 720);
}

void fact_0() {
  ASSERT_EQ(factorial(0), 1);
}

int main() {
  RUN_TEST(fact_1);
  RUN_TEST(fact_3);
  RUN_TEST(fact_6);
  RUN_TEST(fact_0);

  return 0;
}
