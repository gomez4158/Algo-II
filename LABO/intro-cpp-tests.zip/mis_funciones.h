#ifndef MIS_FUNCIONES
#define MIS_FUNCIONES

int factorial(int n);

#endif
