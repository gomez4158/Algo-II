#ifndef CONJUNTO_HPP_
#define CONJUNTO_HPP_

#include <assert.h>

using namespace std;

template <class T>
class Conjunto
{
    public:

        // Constructor. Genera un conjunto vacío.
        Conjunto();

        // Destructor. Debe dejar limpia la memoria.
        ~Conjunto();

        // Inserta un elemento en el conjunto. Si éste ya existe,
        // el conjunto no se modifica.
        void insertar(const T&);

        // Decide si un elemento pertenece al conjunto o no.
        bool pertenece(const T&) const;

        // borra un elemento del conjunto. Si éste no existe,
        // el conjunto no se modifica.
        void remover(const T&);

        // devuelve el mínimo elemento del conjunto según <.
        const T& minimo() const;

        // devuelve el máximo elemento del conjunto según <.
        const T& maximo() const;

        // devuelve la cantidad de elementos que tiene el conjunto.
        unsigned int cardinal() const;

        // muestra el conjunto.
        void mostrar(std::ostream&) const;

    private:

        // la representación de un nodo interno.
        struct Nodo
        {
            // el constructor, toma el elemento al que representa el nodo.
            Nodo(const T& v);
            // el elemento al que representa el nodo.
            T valor;
            // puntero a la raíz del subárbol izquierdo.
            Nodo* izq;
            // puntero a la raíz del subárbol derecho.
            Nodo* der; 
        };

        // puntero a la raíz de nuestro árbol.
        Nodo* raiz;

};

template <class T>
Conjunto<T>::Conjunto() : raiz(NULL)
{}

template <class T>
Conjunto<T>::~Conjunto()
{ /** TODO */ }

template <class T>
bool Conjunto<T>::pertenece(const T& clave) const
{
    assert(false);
    return false;
}

template <class T>
void Conjunto<T>::insertar(const T& clave)
{
    assert(false);
}

template <class T>
Conjunto<T>::Nodo::Nodo(const T& v)
     : valor(v), izq(NULL), der(NULL)
{}

template <class T>
void Conjunto<T>::remover(const T&) {
    assert(false);
}
template <class T>
const T& Conjunto<T>::minimo() const {
    assert(false);
    return 0;
}
template <class T>
const T& Conjunto<T>::maximo() const {
    assert(false);
    return 0;
}

template <class T>
unsigned int Conjunto<T>::cardinal() const {
    assert(false);
    return 0;
}

template <class T>
void Conjunto<T>::mostrar(std::ostream&) const {
    assert(false);
}


#endif // CONJUNTO_HPP_
